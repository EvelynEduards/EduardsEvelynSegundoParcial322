package model;

import java.io.*;
import java.util.*;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public class LibroDeRecetas<T extends CSVSerializable> implements Iterable<T> {

    private List<T> items = new ArrayList<>();

    private void validarItem(T item) {
        if (item == null) {
            throw new NullPointerException("Item nulo.");
        }
    }
    
    private void validarRepetido(T item) {
        if (items.contains(item)) {
            throw new IllegalArgumentException("El item ya se encuentra en el almacen");
        }
    }
    
    public void agregar(T item) {
        validarItem(item);
        validarRepetido(item);
        items.add(item);
    }

    private void validarIndice(int indice) {
        if (indice < 0 || indice >= items.size()) {
            throw new IndexOutOfBoundsException("Indice fuera de rango");
        }
    }
    
    public void eliminarPorIndice(int index) {
        validarIndice(index);
        items.remove(index);
    }

    public T obtenerPorIndice(int indice) {
        validarIndice(indice);
        return items.get(indice);
    }


    public List<T> filtrar(Predicate<? super T> criterio) {
        List<T> resultado = new ArrayList<>();
        for (T item : items) {
            if (criterio.test(item)) resultado.add(item);
        }
        return resultado;
    }

    public void ordenar() {
        if (!items.isEmpty() && items.get(0) instanceof Comparable) {
            items.sort((Comparator<? super T>) Comparator.naturalOrder());
        } else {
            throw new UnsupportedOperationException("El tipo de elemento no es Comparable para orden natural.");
        }
    }

    public void ordenar(Comparator<? super T> comparador) {
        items.sort(comparador);
    }
    
    private void validarRutaArchivo(String rutaArchivo) {
        if (rutaArchivo == null || rutaArchivo.trim().isEmpty()) {
            throw new IllegalArgumentException("La ruta del archivo no puede ser nula o vacía.");
        }
    }

    @Override
    public Iterator<T> iterator() {
        if (!items.isEmpty() && items.get(0) instanceof Comparable) {
            List<T> copia = new ArrayList<>(items);
            copia.sort((Comparator<? super T>) Comparator.naturalOrder());
            return copia.iterator();
        }
        return items.iterator();
    }

    public Iterator<T> iterator(Comparator<? super T> comparador) {
        List<T> copia = new ArrayList<>(items);
        copia.sort(comparador);
        return copia.iterator();
    }

    public void paraCadaElemento(Consumer<? super T> accion) {
        for (T item : items) {
            accion.accept(item);
        }
    }

    public void guardarEnArchivo(String rutaArchivo) throws IOException {
        validarRutaArchivo(rutaArchivo);
        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(rutaArchivo))) {
            salida.writeObject(items);
        }
    }

    public void cargarDesdeArchivo(String rutaArchivo) throws IOException, ClassNotFoundException {
        try (ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(rutaArchivo))) {
            this.items = (List<T>) entrada.readObject();
        }
    }

    public void guardarEnCSV(String rutaArchivo) throws IOException {
        validarRutaArchivo(rutaArchivo);
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(rutaArchivo))) {
            writer.write(Receta.toCSVHeader() + "\n");
            for (T elemento : items) {
                writer.write(elemento.toCSV());
                writer.newLine();
            }
        }
    }

    public void cargarDesdeCSV(String rutaArchivo, Function<String, T> fromCSVFunction) throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(rutaArchivo))) {
            items.clear();
            reader.readLine(); 
            String linea;
            while ((linea = reader.readLine()) != null) {
                T item = fromCSVFunction.apply(linea);
                if (item != null) {
                    items.add(item);
                }
            }
        }
    }
}

