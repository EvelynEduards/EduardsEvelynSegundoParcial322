package model;

import java.util.Objects;

public class Receta implements Comparable<Receta>, CSVSerializable {

    private final int id;
    private final String nombre;
    private final String autor;
    private final TipoReceta tipo;

    public Receta(int id, String nombre, String autor, TipoReceta tipo) {
        this.id = id;
        this.nombre = nombre;
        this.autor = autor;
        this.tipo = tipo;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getAutor() {
        return autor;
    }

    public TipoReceta getTipo() {
        return tipo;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null || !(obj instanceof Receta r)) {
            return false;
        }
        return this.id == r.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public int compareTo(Receta otra) {
        return Integer.compare(this.id, otra.id);
    }

    @Override
    public String toString() {
        return "RECETA : " + nombre +
                "  ID = " + id +
                " NOMBRE = '" + nombre + '\'' +
                " AUTOR = '" + autor + '\'' +
                " TIPO = " + tipo;
    }

    @Override
    public String toCSV() {
        return id + "," + nombre + "," + autor + "," + tipo;
    }

    public static Receta fromCSV(String linea) {
        if (linea.endsWith("\n")) {
            linea = linea.substring(0, linea.length() - 1);
        }
        String[] partes = linea.split(",");
        if (partes.length == 4) {
            int id = Integer.parseInt(partes[0].trim());
            String nombre = partes[1].trim();
            String autor = partes[2].trim();
            TipoReceta tipo = TipoReceta.valueOf(partes[3].strip());
            return new Receta(id, nombre, autor, tipo);
        }
        return null;
    }

    public static String toCSVHeader() {
        return "ID,NOMBRE,AUTOR,TIPO";
    }
}

