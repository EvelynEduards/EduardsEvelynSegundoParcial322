package eduards.evelyn.p2div322;

import model.LibroDeRecetas;
import model.Receta;
import model.TipoReceta;
import java.io.IOException;
import java.util.Comparator;
import config.RutasArchivo;

public class EduardsEvelynP2div322 {

   
    public static void main(String[] args) {
        try {
            // Crear un libro de recetas
            LibroDeRecetas<Receta> libro = new LibroDeRecetas<>();
            libro.agregar(new Receta(1, "Tarta de Verdura", "Abuela Rosa", TipoReceta.VEGETARIANA));
            libro.agregar(new Receta(2, "Pollo al horno", "Juan Pérez", TipoReceta.PLATO_PRINCIPAL));
            libro.agregar(new Receta(3, "Ensalada César", "Laura Ruiz", TipoReceta.ENTRADA));
            libro.agregar(new Receta(4, "Brownie", "Chef Martín", TipoReceta.POSTRE));
            libro.agregar(new Receta(5, "Pan sin gluten", "Lucía Gómez", TipoReceta.SIN_TACC));

            // Mostrar todas las recetas
            System.out.println("Libro de recetas:");
            libro.paraCadaElemento(receta -> System.out.println(receta));

            // Filtrar recetas por tipo VEGETARIANA
            System.out.println("\nRecetas VEGETARIANAS:");
            libro.filtrar(receta -> receta.getTipo() == TipoReceta.VEGETARIANA)
                    .forEach(receta -> System.out.println(receta));

            // Filtrar recetas cuyo nombre contiene "tarta"
            System.out.println("\nRecetas que contienen 'tarta':");
            libro.filtrar(receta -> receta.getNombre().toLowerCase().contains("tarta"))
                    .forEach(receta -> System.out.println(receta));

            // Ordenar recetas por ID (orden natural)
            System.out.println("\nRecetas ordenadas por ID:");
            libro.ordenar();
            libro.paraCadaElemento(receta -> System.out.println(receta));

            // Ordenar recetas por nombre
            System.out.println("\nRecetas ordenadas por nombre:");
            libro.ordenar(Comparator.comparing(receta -> receta.getNombre()));


            // Guardar el libro en archivo binario
            libro.guardarEnArchivo(RutasArchivo.getRutaBinString());

            // Cargar el libro desde archivo binario
            LibroDeRecetas<Receta> libroCargado = new LibroDeRecetas<>();
            libroCargado.cargarDesdeArchivo(RutasArchivo.getRutaBinString());
            System.out.println("\nRecetas cargadas desde archivo binario:");
            libroCargado.paraCadaElemento(receta -> System.out.println(receta));

            // Guardar el libro en archivo CSV
            libro.guardarEnCSV(RutasArchivo.getRutaCSVString());

            // Cargar el libro desde archivo CSV
            libroCargado.cargarDesdeCSV(RutasArchivo.getRutaCSVString(), linea -> Receta.fromCSV(linea));
            System.out.println("\nRecetas cargadas desde archivo CSV:");
            libroCargado.paraCadaElemento(receta -> System.out.println(receta));

        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}
