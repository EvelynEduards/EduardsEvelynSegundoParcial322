package config;

import java.nio.file.Path;
import java.nio.file.Paths;

public interface RutasArchivo {
    static final String BASE = "src/data";

    static final String BINARY_FILE_PATH = "recetas.dat";
    static final String CSV_FILE_PATH = "recetas.csv";

    public static Path getRutaCSV() {
        return Paths.get(BASE, CSV_FILE_PATH);
    }

    public static Path getRutaBin() {
        return Paths.get(BASE, BINARY_FILE_PATH);
    }

    public static String getRutaCSVString() {
        return getRutaCSV().toString();
    }

    public static String getRutaBinString() {
        return getRutaBin().toString();
    }
}
